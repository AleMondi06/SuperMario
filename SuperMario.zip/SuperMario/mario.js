// Riferimento all'elemento HTML dell'immagine di Mario, del tubo e del fungo
var mario = document.getElementById("mario");
var tubo = document.getElementById("pipe");
var fungo = document.getElementById("mushroom");
var backgroundMusic = document.getElementById("background-music");
var jumpSound = document.getElementById("jump-sound");

// Riferimento al pulsante di avvio del gioco
var pulsanteAvvio = document.getElementById("start-btn");

// Listener per l'evento di clic sul pulsante di avvio
pulsanteAvvio.addEventListener("click", function () {
  backgroundMusic.play();
  // Nascondo il pulsante di avvio
  pulsanteAvvio.style.display = "none";
  // Mostro il contenitore del gioco
  document.getElementById("game-container").style.display = "block";
  // Avvio il gioco
  avviaGioco();
});

// Definire la funzione per avviare il gioco
function avviaGioco() {
  // Variabile per gestire il salto di Mario
  var marioSalto = false;
  // Variabile per gestire il movimento a destra di Mario
  var marioDestra = false;
  // Variabile per gestire il movimento a sinistra di Mario
  var marioSinistra = false;
  // Array contenente gli ostacoli (tubo e fungo)
  var ostacoli = [tubo, fungo];
  // Larghezza del contenitore di gioco
  var larghezzaContenitore = document.getElementById("game-container").offsetWidth;
  // Posizione iniziale di Mario
  var posizioneMario = 50;

  // Funzione per il salto di Mario
  function salta() {
    if (!marioSalto) {
      marioSalto = true;
      jumpSound.play();
      var posizioneIniziale = 59;
      var posizioneFinale = 180;
      var velocitaSalto = 10;

      var intervalloSalto = setInterval(function () {
        if (posizioneIniziale < posizioneFinale) {
          posizioneIniziale += velocitaSalto;
          mario.style.bottom = posizioneIniziale + "px";
        } else {
          clearInterval(intervalloSalto);
          cade();
        }
      }, 20);
    }
  }

  // Funzione per far cadere Mario dopo il salto
  function cade() {
    var posizioneIniziale = 180;
    var posizioneFinale = 59;
    var velocitaCaduta = 10;

    var intervalloCaduta = setInterval(function () {
      if (posizioneIniziale > posizioneFinale) {
        posizioneIniziale -= velocitaCaduta;
        mario.style.bottom = posizioneIniziale + "px";
      } else {
        clearInterval(intervalloCaduta);
        marioSalto = false;
      }
    }, 20);
  }

  // Funzione per il movimento di Mario a destra o a sinistra
  function muoviMario(direzione) {
    var posizioneProposta = posizioneMario + (direzione === "destra" ? 20 : -20);
    var posizioneMassima = larghezzaContenitore - mario.offsetWidth;
    if (posizioneProposta >= 0 && posizioneProposta <= posizioneMassima) {
      posizioneMario = posizioneProposta;
      mario.style.left = posizioneMario + "px";
      if (direzione === "destra") {
        mario.classList.remove("flipped");
      } else {
        mario.classList.add("flipped");
      }
    }
  }
// Funzione per far muovere un ostacolo
function muoviOstacolo(ostacolo) {
  var posizioneOstacolo = larghezzaContenitore;
  ostacolo.style.left = posizioneOstacolo + "px";
  var velocitaMovimento = 10; // Velocità di base

  var intervalloOstacolo = setInterval(function () {
    if (posizioneOstacolo < -60) {
      ostacolo.style.display = "none";
      posizioneOstacolo = larghezzaContenitore;
      setTimeout(() => {
        ostacolo.style.display = "block";
        // Aumenta la velocità ogni volta che l'ostacolo riappare
        velocitaMovimento += 2; // Puoi regolare la velocità di aumento come preferisci
      }, 100);
    } else {
      posizioneOstacolo -= velocitaMovimento;
      ostacolo.style.left = posizioneOstacolo + "px";
    }
  }, 50); // Intervallo di aggiornamento del movimento
}

  // Listener per l'evento di pressione del tasto
  window.addEventListener("keydown", function (event) {
    switch (event.key) {
      case " ":
        salta();
        break;
      case "d":
        marioDestra = true;
        break;
      case "a":
        marioSinistra = true;
        break;
    }
  });

  // Listener per l'evento di rilascio del tasto
  window.addEventListener("keyup", function (event) {
    switch (event.key) {
      case "d":
        marioDestra = false;
        break;
      case "a":
        marioSinistra = false;
        break;
    }
  });

  // Movimento di Mario periodico
  setInterval(function () {
    if (marioDestra) {
      muoviMario("destra");
    } else if (marioSinistra) {
      muoviMario("sinistra");
    }
  }, 100);

  // Avvia il movimento degli ostacoli
  ostacoli.forEach(function (ostacolo, indice) {
    setTimeout(function () {
      ostacolo.style.display = "block";
      muoviOstacolo(ostacolo);
    }, indice * 2000);
  });
}
