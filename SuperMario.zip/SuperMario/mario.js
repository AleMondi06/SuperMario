var mario = document.getElementById("mario");

function startGame() {
  var marioJumping = false;
  var marioMovingLeft = false;
  var marioMovingRight = false;
  var gameContainerWidth =
    document.getElementById("game-container").offsetWidth;
  var marioPosition = 50;

  function jump() {
    if (!marioJumping) {
      marioJumping = true;
      var startPos = 32;
      var endPos = 150;
      var speed = 5;

      var jumpInterval = setInterval(function () {
        if (startPos < endPos) {
          startPos += speed;
          mario.style.bottom = startPos + "px";
        } else {
          clearInterval(jumpInterval);
          fall();
        }
      }, 20);
    }
  }

  function fall() {
    var startPos = 150;
    var endPos = 32;
    var speed = 8;

    var fallInterval = setInterval(function () {
      if (startPos > endPos) {
        startPos -= speed;
        mario.style.bottom = startPos + "px";
      } else {
        clearInterval(fallInterval);
        marioJumping = false;
      }
    }, 20);
  }

  function moveMario(direction) {
    var proposedPosition = marioPosition + (direction === "right" ? 20 : -20);
    var maxMarioPosition = gameContainerWidth - mario.offsetWidth;
    if (proposedPosition >= 0 && proposedPosition <= maxMarioPosition) {
      marioPosition = proposedPosition;
      mario.style.left = marioPosition + "px";
      if (direction === "right") {
        mario.classList.remove("flipped");
      } else {
        mario.classList.add("flipped");
      }
    }
  }

  window.addEventListener("keydown", function (event) {
    switch (event.key) {
      case " ":
        jump();
        break;
      case "a":
        marioMovingLeft = true;
        break;
      case "d":
        marioMovingRight = true;
        break;
    }
  });

  window.addEventListener("keyup", function (event) {
    switch (event.key) {
      case "a":
        marioMovingLeft = false;
        break;
      case "d":
        marioMovingRight = false;
        break;
    }
  });

  setInterval(function () {
    if (marioMovingRight) {
      moveMario("right");
    } else if (marioMovingLeft) {
      moveMario("left");
    }
  }, 100);
}

startGame(); // avvio automatico del gioco
