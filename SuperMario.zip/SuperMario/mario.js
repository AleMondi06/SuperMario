var mario = document.getElementById("mario");
var startBtn = document.getElementById("start-btn");

// Aggiungere un listener per l'evento di clic sul pulsante di avvio
startBtn.addEventListener("click", function () {
  // Nascondere il pulsante di avvio
  startBtn.style.display = "none";
  // Mostrare il contenitore del gioco
  document.getElementById("game-container").style.display = "block";
  // Avviare il gioco
  startGame();
});

// Definire la funzione per avviare il gioco
function startGame() {
  // Variabili per il movimento di Mario
  var marioJumping = false;
  var marioMovingLeft = false;
  var marioMovingRight = false;

  // Ottenere la larghezza del contenitore del gioco
  var gameContainerWidth = document.getElementById("game-container").offsetWidth;

  // Posizione iniziale di Mario
  var marioPosition = 50;

  // Funzione per far saltare Mario
  function jump() {
    if (!marioJumping) {
      marioJumping = true;
      var startPos = 59;
      var endPos = 150;
      var speed = 5;

      var jumpInterval = setInterval(function () {
        if (startPos < endPos) {
          startPos += speed;
          mario.style.bottom = startPos + "px";
        } else {
          clearInterval(jumpInterval);
          fall();
        }
      }, 20);
    }
  }

  // Funzione per far cadere Mario
  function fall() {
    var startPos = 150;
    var endPos = 59;
    var speed = 8;

    var fallInterval = setInterval(function () {
      if (startPos > endPos) {
        startPos -= speed;
        mario.style.bottom = startPos + "px";
      } else {
        clearInterval(fallInterval);
        marioJumping = false;
      }
    }, 20);
  }

  // Funzione per muovere Mario a sinistra o a destra
  function moveMario(direction) {
    var proposedPosition = marioPosition + (direction === "right" ? 20 : -20);
    var maxMarioPosition = gameContainerWidth - mario.offsetWidth;
    if (proposedPosition >= 0 && proposedPosition <= maxMarioPosition) {
      marioPosition = proposedPosition;
      mario.style.left = marioPosition + "px";
      if (direction === "right") {
        mario.classList.remove("flipped");
      } else {
        mario.classList.add("flipped");
      }
    }
  }

  // Aggiungere un listener per l'evento di pressione del tasto
  window.addEventListener("keydown", function (event) {
    switch (event.key) {
      case " ":
        jump();
        break;
      case "a":
        marioMovingLeft = true;
        break;
      case "d":
        marioMovingRight = true;
        break;
    }
  });

  // Aggiungere un listener per l'evento di rilascio del tasto
  window.addEventListener("keyup", function (event) {
    switch (event.key) {
      case "a":
        marioMovingLeft = false;
        break;
      case "d":
        marioMovingRight = false;
        break;
    }
  });

  // Eseguire periodicamente il movimento di Mario
  setInterval(function () {
    if (marioMovingRight) {
      moveMario("right");
    } else if (marioMovingLeft) {
      moveMario("left");
    }
  }, 100);
}

// Avviare il gioco automaticamente
startGame();
