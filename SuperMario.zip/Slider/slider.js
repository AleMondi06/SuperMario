//init object globally
var objImage = null;
var x = 0;
function init() {
    objImage = document.getElementById("immagine");
    objImage.style.position = "relative";
    objImage.style.left = "0px";
    objImage.style.top = "830px";
}
function getKeyAndMove(e) {
    var key_code = e.which || e.keyCode;
    switch (key_code) {
        case 65: //a key
            moveLeft();
            break;
        case 87: //w key
            moveUp();
            break;
        case 68: //d key
            moveRight();
            break;
        case 83: //s key
            moveDown();
            break;
        case 32: //space
            for(var i=0; i < 10; i++){
                x = 0;
                moveUpSlowly();
            }
            break;
    }
}
function moveLeft() {
    objImage.style.left = parseInt(objImage.style.left) - 5 + "px";
}
function moveRight() {
    objImage.style.left = parseInt(objImage.style.left) + 5 + "px";
}
function moveUp() {
    objImage.style.top = parseInt(objImage.style.top) - 5 + "px";
}
function moveUpSlowly() {
    if(x >= 12)
        return;
    objImage.style.top = parseInt(objImage.style.top) - 5 + "px";
    x++;
    id = setTimeout(moveUpSlowly,100);
}
function moveDown() {
    objImage.style.top = parseInt(objImage.style.top) + 5 + "px";
}

window.onload = init;